package com.praveen.psr.pdfreader;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import com.maveric.psr.PDFBlockTextReaderLibrary.PDFBlock;
import com.maveric.psr.PDFBlockTextReaderLibrary.PDFBlockListGenerator;
import com.maveric.psr.PDFBlockTextReaderLibrary.PDFBlockReader;
import com.maveric.psr.PDFBlockTextReaderLibrary.PDFBlockStructure;
import com.maveric.psr.PDFBlockTextReaderLibrary.PDFLineData;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Dell
 */
public class PDFBlockReaderPOC {

    public static void main(String[] args) throws IOException {
        
        String[] RootBlocks = {"Charge Details", "Settlement Summary"};//Main Blocks
        String[] ChargeDetailsBlocks = {"CASH-ACCOUNT SERVICES", "CASH-BANK PAYMENTS", "CASH-COLLECTIONS"};//Sub Blocks
        File pdffile = new File("C:\\Users\\Lenovo\\Desktop\\HK_58593_ACCOUNT_18505377_20190201.pdf");

        //Creating a Block Structure
        ArrayList<PDFBlock> RootPDFBlocks = PDFBlockListGenerator.generatePDFBlocks(RootBlocks);//Generate PDFBlock Objects
        ArrayList<PDFBlock> ChargeDetailsPDFBlocks = PDFBlockListGenerator.generatePDFBlocks(ChargeDetailsBlocks);//Generate PDFSubBlock Objects

        for (int i = 0; i < RootPDFBlocks.size(); i++) {
            PDFBlock EachBlock = RootPDFBlocks.get(i);
            if (EachBlock.BlockName.equals("Charge Details")) {
                EachBlock.addSubBlocks(ChargeDetailsPDFBlocks);//Add SubBlocks
            }
        }
        PDFBlockStructure PDFBlockStructureHKBill = new PDFBlockStructure(RootPDFBlocks);//Creating the Structure with Blocks

        //Reading the PDF with the Defined Structure
        PDFBlockReader Reader = new PDFBlockReader(pdffile, PDFBlockStructureHKBill);// Reading the PDF as per the structure
        PDFLineData Data = new PDFLineData(Reader.readPDFwithBlockStructure());//Getting the PDF line into a Data Object

       
        Data.findKeyValuePair("Transaction", "225.00", " Fee HKD  ");//Searching the Key value pair in the Data

    }
}
