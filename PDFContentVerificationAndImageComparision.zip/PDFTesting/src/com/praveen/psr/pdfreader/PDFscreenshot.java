package com.praveen.psr.pdfreader;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;
import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class PDFscreenshot {
	static WebDriver driver;
	static int count;
	static ExtentTest test;
	static ExtentReports report;
	static Map<Integer, String> map = new HashMap<Integer, String>();
	static Robot robot;
	static int screenshotcount;

	public static float compareImageRGBData(String File1, String File2, String comparisionresult) throws IOException {

		String newPDFscreenshots = new File("./NewPDFScreenshot").getAbsolutePath();
		String oldPDFscreenshots = new File("./OldPDFScreenshot").getAbsolutePath();
		String resultPath = new File("./ComparisonResult").getAbsolutePath();
		String oldImage = oldPDFscreenshots + "\\" + File1;
		String newImage = newPDFscreenshots + "\\" + File2;
		test.log(LogStatus.INFO, "Old PDF screenshot" + test.addScreenCapture(oldImage));
		test.log(LogStatus.INFO, "New PDF screenshot" + test.addScreenCapture(newImage));
		String resultImage = resultPath + "\\" + comparisionresult;
		float x;
		int largerwidth;
		int largerheight;
		long start = System.currentTimeMillis();
		File file = new File(oldImage);
		File files = new File(newImage);
		File Result = new File(resultImage + ".png");
		BufferedImage resultimage = ImageIO.read(file);
		BufferedImage image = ImageIO.read(file);
		int width = image.getWidth(null);
		int height = image.getHeight(null);
		int[][] clr = new int[width][height];
		BufferedImage images = ImageIO.read(files);
		if (image.equals(images)) {
			System.out.println("Buffered Image Object is equal");
		}
		int widthe = images.getWidth(null);
		int heighte = images.getHeight(null);
		int[][] clre = new int[widthe][heighte];
		int smw = 0;
		int smh = 0;
		int p = 0;
		// CALUCLATING THE SMALLEST VALUE AMONG WIDTH AND HEIGHT
		if (width > widthe) {
			smw = widthe;
			largerwidth = width;
		} else {
			smw = width;
			largerwidth = widthe;
		}
		if (height > heighte) {
			smh = heighte;
			largerheight = height;
		} else {
			smh = height;
			largerheight = heighte;
		}
		// CHECKING NUMBER OF PIXELS SIMILARITY
		for (int a = 0; a < smw; a++) {
			for (int b = 0; b < smh; b++) {
				clre[a][b] = images.getRGB(a, b);
				clr[a][b] = image.getRGB(a, b);
				if (clr[a][b] == clre[a][b]) {
					p = p + 1;
				} else {
					// red
					resultimage.setRGB(a, b, -1237980);

				}
			}
		}

		float w, h = 0;
		if (width > widthe) {
			w = width;
		} else {
			w = widthe;
		}
		if (height > heighte) {
			h = height;
		} else {
			h = heighte;
		}
		float s = (smw * smh);
		// CALUCLATING PERCENTAGE
		x = (100 * p) / s;
		ImageIO.write(resultimage, "png", Result);
		String resultpath = Result.getAbsolutePath();
		test.log(LogStatus.INFO, "Result screenshot" + test.addScreenCapture(resultpath));
		System.out.println("THE PERCENTAGE SIMILARITY IS APPROXIMATELY =" + x + "%");
		long stop = System.currentTimeMillis();
		System.out.println("TIME TAKEN IS =" + (stop - start) + "ms");
		return x;
	}

	public static void takingScreenshot(String pagename, String pdfValue) throws IOException {

		TakesScreenshot scrShot = ((TakesScreenshot) PDFscreenshot.driver);
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		String newPDFscreenshots = new File("./NewPDFScreenshot").getAbsolutePath();
		String oldPDFscreenshots = new File("./OldPDFScreenshot").getAbsolutePath();
		if (pdfValue.equalsIgnoreCase("old")) {
			String path = oldPDFscreenshots + "\\" + pagename + ".png";
			String screenshotname = pagename + ".png";
			map.put(count, screenshotname);
			count++;
			File file = new File(path);
			FileUtils.copyFile(SrcFile, file);

		} else if (pdfValue.equalsIgnoreCase("new")) {
			String path = newPDFscreenshots + "\\" + pagename + ".png";
			File file = new File(path);
			FileUtils.copyFile(SrcFile, file);

		}
	}

	public static void pdfurls(String url, String pdfValue) throws InterruptedException, AWTException, IOException {

		driver.get(url);
		Thread.sleep(6000);
		PDFscreenshot.setZoomLevel();
		Thread.sleep(8000);
		int size = Integer.parseInt(PDFscreenshot.getpropertyValue("PageNumbers"));
		PDFscreenshot.takingScreenshot("FirstPage", pdfValue);
		for (int i = 0; i < size; i++) {

				int pagecovCount = i + 1;
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				PDFscreenshot.takingScreenshot("pagepart " + pagecovCount + "_1", pdfValue);
				Thread.sleep(500);
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				PDFscreenshot.takingScreenshot("pagepart " + pagecovCount + "_2", pdfValue);		
		}
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		PDFscreenshot.takingScreenshot("Last Page", pdfValue);

	}

	public static void setZoomLevel() {
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_0);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_0);

	}

	public static String getcurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-ddHH-mm-ss");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		return currentDate;

	}

	public static String getpropertyValue(String inputValue) {
		String outputValue = "";

		try {
			FileInputStream input = new FileInputStream(new File("./inputDetails.properties"));
			Properties prop = new Properties();
			prop.load(input);
			outputValue = prop.getProperty(inputValue);
			return outputValue;

		}

		catch (Exception e) {
			// TODO: handle exception
			return "Exception while taking property value";
		}

	}

	public static void main(String[] args) throws IOException, InterruptedException, AWTException {
		// TODO Auto-generated method stub
		String chromepath = new File("./drivers/chromedriver.exe").getAbsolutePath();
		System.setProperty("webdriver.chrome.driver", chromepath);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		robot = new Robot();
		String path = new File("./Reports").getAbsolutePath();
		System.out.println(PDFscreenshot.getcurrentDate());
		report = new ExtentReports(path + "\\" + PDFscreenshot.getcurrentDate() + "_ExtentReportResults.html");
		test = report.startTest("ExtentDemo");
		PDFscreenshot.pdfurls(getpropertyValue("OldPDF"), "old");
		PDFscreenshot.pdfurls(getpropertyValue("NewPDF"), "new");
		test.log(LogStatus.INFO, "OldPDF path - " + PDFscreenshot.getpropertyValue("OldPDF"));
		test.log(LogStatus.INFO, "NewPDF path - " + PDFscreenshot.getpropertyValue("NewPDF"));
		for (Entry<Integer, String> entry : map.entrySet()) {
			String value = entry.getValue();
			String[] screenshotname = value.split("\\.");
			String comparisionresult = screenshotname[0];
			PDFscreenshot.compareImageRGBData(value, value, comparisionresult);
			report.endTest(test);
			report.flush();
		}

	}

}
